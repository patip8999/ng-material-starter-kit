export interface UserWithRoleQueryModel {
  readonly email: string;
  readonly role: string;
}
