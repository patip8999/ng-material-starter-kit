export interface JobWithTagsQueryModel {
  readonly title: string;
  readonly jobTags: string[];
}
