export interface UsersWithRolesAndDepartmentsQueryModel {
  readonly email: string;
  readonly role: string;
  readonly department: string;
}
