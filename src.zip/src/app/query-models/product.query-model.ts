export interface ProductQueryModel {
    readonly name: string;
    readonly price: number;
    readonly stock: number;
    readonly id: string;
  }

