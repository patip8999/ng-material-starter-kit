export interface CityModel {
  readonly name: string;
  readonly id: number;
}
