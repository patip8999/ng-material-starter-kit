export interface ProductModel {
  readonly id: string;
  readonly title: string;
  readonly price: string;
  readonly category: string;
  readonly description: string;
  readonly image: string;
}
