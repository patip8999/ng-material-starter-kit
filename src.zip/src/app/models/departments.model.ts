export interface DepartmentsModel {
  readonly name: string;
  readonly id: string;
}
