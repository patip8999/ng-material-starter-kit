export interface JobTagModel {
  readonly name: string;
  readonly id: string;
}
