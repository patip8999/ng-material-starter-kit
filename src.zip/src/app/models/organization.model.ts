export interface OrganizationModel {
  readonly name: string;
  readonly id: string;
}
