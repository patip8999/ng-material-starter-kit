export interface RoleModel {
  readonly id: string;
  readonly role: string;
}
