export interface CryptoModel {
  readonly symbol: string;
  readonly priceChange: string;
}
