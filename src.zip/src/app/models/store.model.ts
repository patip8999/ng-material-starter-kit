export interface StoreModel {
    readonly stock: number;
    readonly delivery: number;
    readonly id: string;
    readonly productId: string;
}
