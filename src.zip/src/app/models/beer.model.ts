export interface BeerModel {
  readonly id: number;
  readonly name: string;
}
