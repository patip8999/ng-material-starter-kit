export interface CatModel {
  readonly breed: string;
  readonly cityName: string;
  readonly price: string;
  readonly name: string;
}
