export interface UniveristyModel {
  readonly name: string;
  readonly country: string;
}
