export interface TeamModel {
  readonly name: string;
  readonly userIds: string[];
  readonly id: string;
  readonly organizationId: string;
}