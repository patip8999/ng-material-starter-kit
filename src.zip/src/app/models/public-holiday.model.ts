export interface PublicHolidayModel {
  readonly localName: string;
}
