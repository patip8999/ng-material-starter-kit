export interface JobModel {
  readonly title: string;
  readonly description: string;
  readonly corporate: string;
  readonly jobTagIds: number[];
  readonly id: string;
}
